THEJUSJOSEPH.IN — START HERE PAGE

Upload both files to the same folder as index.html:
1. start-here.html
2. thejus-start-here-portrait.webp

The page currently links the booking buttons to book.html. When the booking page or external scheduling link is ready, replace every occurrence of:
  href="book.html"
with the final URL.

The main navigation links back to sections in index.html until separate Learn, Guides, Questions and About pages are created.
